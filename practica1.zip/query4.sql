 WITH seats_per_flight
     AS (SELECT f.flight_id,
                Count(s.seat_no) AS total_seats
         FROM   PUBLIC.flights f
                LEFT JOIN PUBLIC.seats s
                       ON f.aircraft_code = s.aircraft_code
         GROUP  BY f.flight_id
         ORDER  BY f.flight_id ASC),
     occupied_per_flight
     AS (SELECT f.flight_id,
                Count(bp.seat_no) AS occupied_seats
         FROM   PUBLIC.flights f
                LEFT JOIN PUBLIC.boarding_passes bp
                       ON bp.flight_id = f.flight_id
         GROUP  BY f.flight_id),
     vacant_seats
     AS (SELECT spf.flight_id,
                spf.total_seats,
                opf.occupied_seats,
                ( spf.total_seats - opf.occupied_seats ) AS num_empty
         FROM   seats_per_flight spf
                JOIN occupied_per_flight opf
                  ON spf.flight_id = opf.flight_id
         GROUP  BY spf.flight_id,
                   spf.total_seats,
                   opf.occupied_seats)
SELECT v.flight_id,
       v.num_empty
FROM   vacant_seats v
WHERE  v.occupied_seats > 0
       AND v.num_empty = (SELECT Max(vs.num_empty)
                          FROM   vacant_seats vs
                          WHERE  vs.occupied_seats > 0)
ORDER  BY v.num_empty DESC;
