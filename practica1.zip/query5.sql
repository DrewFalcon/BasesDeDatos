SELECT DISTINCT b.book_ref,
                tf.flight_id
FROM   PUBLIC.bookings b
       JOIN PUBLIC.tickets t
         ON b.book_ref = t.book_ref
       JOIN PUBLIC.ticket_flights tf
         ON t.ticket_no = tf.ticket_no
       LEFT JOIN PUBLIC.boarding_passes bp
              ON tf.ticket_no = bp.ticket_no
                 AND tf.flight_id = bp.flight_id
WHERE  bp.ticket_no IS NULL
ORDER  BY b.book_ref ASC,
          tf.flight_id ASC;