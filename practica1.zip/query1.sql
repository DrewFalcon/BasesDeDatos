WITH first_tickets
     AS (SELECT DISTINCT ON (tf.ticket_no)
        tf.ticket_no,
        f.departure_airport AS first_departure
         FROM   PUBLIC.tickets t
                JOIN PUBLIC.ticket_flights tf
                  ON t.ticket_no = tf.ticket_no
                JOIN PUBLIC.flights f
                  ON tf.flight_id = f.flight_id
         ORDER  BY tf.ticket_no,
                   f.scheduled_departure ASC,
                   f.flight_id ASC),
     last_tickets
     AS (SELECT DISTINCT ON (tf.ticket_no) tf.ticket_no,
                                           f.arrival_airport AS last_arrival
         FROM   PUBLIC.tickets t
                JOIN PUBLIC.ticket_flights tf
                  ON t.ticket_no = tf.ticket_no
                JOIN PUBLIC.flights f
                  ON tf.flight_id = f.flight_id
         ORDER  BY tf.ticket_no,
                   f.scheduled_departure DESC,
                   f.flight_id DESC),
     first_and_lasts
     AS (SELECT f.ticket_no,
                f.first_departure,
                l.last_arrival,
                t.book_ref
         FROM   first_tickets f
                JOIN last_tickets l
                  ON f.ticket_no = l.ticket_no
                JOIN PUBLIC.tickets t
                  ON f.ticket_no = t.ticket_no)
SELECT fal.first_departure AS Airport,
       Count(DISTINCT fal.book_ref)
FROM   first_and_lasts fal
WHERE  fal.first_departure = fal.last_arrival
GROUP  BY fal.first_departure
ORDER  BY fal.first_departure ASC;