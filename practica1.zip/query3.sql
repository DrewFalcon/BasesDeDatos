SELECT a.airport_code,
       Count(b.boarding_no) AS num_passen
FROM   PUBLIC.airports_data a
       JOIN PUBLIC.flights f
         ON a.airport_code = f.arrival_airport
       JOIN PUBLIC.ticket_flights tf
         ON tf.flight_id = f.flight_id
       JOIN PUBLIC.boarding_passes b
         ON b.ticket_no = tf.ticket_no
GROUP  BY a.airport_code
ORDER  BY num_passen ASC;